
  <html ng-app="MyApplication">
  <head>

  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="<?php echo base_url('text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons')?>" />
  <link rel="stylesheet" href="<?php echo base_url('https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css')?>">
  <!-- CSS Files -->
  <link href="<?php echo base_url('asset/css/material-dashboard.css?v=2.1.2')?>" rel="stylesheet" />



  <script src="<?php echo base_url('asset/angularjs/angular.min.js')?>"></script>
  <script src="<?php echo base_url('asset/angularjs/angular-sanitize.min.js') ?>"></script>
  <script src="<?php echo base_url('folder/app.js')?>"></script>
  <link rel="stylesheet" href="<?php echo base_url('folder/style_table.css')?>">
<script type="text/javascript">
  var BASEURL='<?php echo base_url();?>';
</script>

  
  </head>
 
 <body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="white">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag 
    -->
      <div class="logo">
          Pre-Registration
        </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="<?php echo base_url('patients/view-patient');?>">
              <p>Patient's</p>
            </a>
          </li> 
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo base_url('patients/in-patient-record');?>">
              <!-- <i class="material-icons">person</i> -->
              <p>In-Patient Record</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo base_url('patients/out-patient-record');?>">
              <!-- <i class="material-icons">content_paste</i> -->
              <p>Out-Patient Record</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;"></a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            
            <ul class="navbar-nav">
              <li class="nav-item dropdown">
                <a class="nav-link" href="javascript:;" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="material-icons">User</i>
                 
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                  <a class="dropdown-item" href="#">user</a>
                  <a class="dropdown-item" href="#">Settings</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="<?php echo base_url('patients/log-out');?>"">Log out</a>
                </div>
              </li> 
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->

<div ng-controller="Controller1" ng-init="searchform()" class="content">


    
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title ">Patient's Data</h4>
                  <!-- <p class="card-category"> Here is a subtitle for this table</p> -->
                  <!-- <a type="button" class="btn btn-primary pull-right" href="<?php echo base_url('patients/new-patient');?>">Add Patient</a> -->
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    


  <div ng-controller="Controller1" ng-init="Init('<?php echo $id; ?>')">
        

        <!-- <form ng-submit="SUBMITFORM()" autocomplete="off"> -->
          <form action="<?php echo base_url().'Patients/UpdatePatient/'.$this->uri->segment(3)?>" METHOD="POST">



        <!-- <a class="button" href="<?php echo base_url('patients/view-patient');?>"> VIEW DATA</a> -->





        <div class="tabset">
          <!-- Tab 1 -->
          <input type="radio" name="tabset" id="tab1" aria-controls="marzen" checked>
          <label for="tab1">Personal Information</label>
          <!-- Tab 2 -->
          <input type="radio" name="tabset" id="tab2" aria-controls="rauchbier">
          <label for="tab2">Family Information</label>
          <!-- Tab 3 -->
          <input type="radio" name="tabset" id="tab3" aria-controls="dunkles">
          <label for="tab3">PHIC Information</label>
          
          <div class="tab-panels">
            <section id="marzen" class="tab-panel">
             

                      <!-- <div class="head">
                        <h1>Patient information</h1>
                      </div> -->

                      <div class="container">
                        <table>
                              <tr>
                              <th>Patient information</th>
                              </tr>  
                              
                              <tr>
                                <td>Lastname:<input type="text" name="LASTNAME" ng-model="FORM.LASTNAME"required="required"></td>


                                <td>Firstname:<input type="text" name="FIRSTNAME" ng-model="FORM.FIRSTNAME"required="required">
                                </td>


                                <td>Middlename:<input type="text"  name="MIDDLENAME" ng-model="FORM.MIDDLENAME" required="required"></td> 


                                <td>Suffix:<input type="text" name="SUFFIX" ng-model="FORM.SUFFIX" required="required"></td>


                              </tr>
                              <tr>


                                <td>Sex: 
                                      <select ng-model="FORM.SEX" name="SEX" required="required">
                                      <option value="male">Male</option>
                                      <option value="female">Female</option>
                                     </select>
                                 </td>

                                  <td>Civil Status:
                                    <select ng-model="FORM.CIVIL_STATUS" name="CIVIL_STATUS"required="required">
                                      <option value="single">Single</option>
                                      <option value="married">Married</option>
                                      <option value="child">Child</option>
                                      <option value="separated">Separated</option>
                                      <option value="widow">Widow</option>
                                     </select>
                                 </td>


                                     <td>DOB:
                                  <input ng-model="FORM.DATE_OF_BIRTH"type="date" name="DATE_OF_BIRTH" required="required">
                                 </td>


                                  <td>NB Condition:<input type="text" name="NBCONDITION" ng-model="FORM.NBCONDITION" required="required"></td>
                                  </td>
                               

                                
                              </tr>

                               <tr>
                                <td>File No.:<input ng-model="FORM.FILE_NO"  type="text" name="FILE_NO" required="required"></td>

                                <td>Date Reg.:<input type="date" name="DATEREG" ng-model="FORM.DATEREG" required="required"></td>

                                 <td>Occupation:<input type="text"  name="OCCUPATION" ng-model="FORM.OCCUPATION" required="required"></td>

                                 
                                 <td>Religion: 
                                    <select ng-model="FORM.RELIGION "name="RELIGION" required="required">
                                      <option value="UP">UNITED PENTECOSTAL</option>
                                      <option value="SDA">SEVENTH DAY ADVENTIST</option>
                                      <option value="ISLAM">ISLAM</option>
                                      <option value="AGLIPAYAN">AGLIPAYAN</option>
                                      <option value="UCCP">UCCP</option>
                                      <option value="INC">IGLESIA NI CRISTO</option>
                                      <option value="PENTECOST">PENTECOST</option>
                                      <option value="MORMONS">LATER DAY SAINTS(MORMONS)</option>
                                    </select>
                                  </td>
                                 
                                
                              </tr>

                               <tr>
                                 
                                  <td>Nationality:
                                    <select ng-model="FORM.NATIONALITY" name="NATIONALITY" required="required">
                                      <option value="japaness">Japaness</option>
                                      <option value="filipino">Filipino</option>
                                      <option value="american">American</option>
                                    </select>
                                 </td>   

                                 <td>Tel no.:<input type="text" name="TELNO" ng-model="FORM.TELNO" required="required"></td> 

                                 <td>Place of Birth:<input ng-model="FORM.PLACE_BIRTH" type="text" name="PLACE_BIRTH" required="required"></td>
                                  
                              </tr>

                        </table> 

                      </div>




                

                     <!--  <div class="head">
                        <h1>Complete Address</h1>
                      </div> -->

                      <div class="container">
                        <table>    

                              <tr>
                              <th>Complete Address</th>
                              </tr>  
                        
                              <tr>
                                <td>No. Street:<input type="text" name="NO_STREET" ng-model="FORM.NO_STREET" ></td>


                                <td>Province:<input type="text" name="PROVINCE" ng-model="FORM.PROVINCE"></td>

                                <td>City Municipality:<input type="text" name="CITY_MUNICIPALITY" ng-model="FORM.CITY_MUNICIPALITY" ></td>
                               

                              </tr>
                              <tr>  

                                <td>Barangay:<input type="text"  name="BARANGAY" ng-model="FORM.BARANGAY" ></td>
                                 
                                 <td>Zipcode:<input type="text" name="ZIPCODE" ng-model="FORM.ZIPCODE" ></td>
                                
                              </tr>
                        </table>
                        
                         </table>

                      </div>


                      <!-- <div class="head">
                        <h1>Others</h1>
                      </div> -->

                      <div class="container">
                         <table>     
                              <tr>
                              <th>Others</th>
                              </tr> 
                            
                              <tr>
                                <td>Company:<input type="text" name="COMPANY" ng-model="FORM.COMPANY" autocomplete="off"></td>

                                 <td>Address:<input type="text" name="ADDRESS" ng-model="FORM.ADDRESS" autocomplete="off"></td>

                                 <td>Health Insurance:<input type="text" name="HEALTH_INSURANCE" ng-model="FORM.HEALTH_INSURANCE"></td>


                                  <td>Address:<input type="text" name="HEALTH_INSURANCE_ADDRESS" ng-model="FORM.HEALTH_INSURANCE_ADDRESS"></td>


                              </tr> 
                              <tr>
                                 <td>Credit Limit:<input type="text" name="CREDIT_LIMIT" ng-model="FORM.CREDIT_LIMIT" autocomplete="off"></td>

                                 <td>Senior Citizen No.:<input type="text" name="SENIOR_CITIZEN_NO" ng-model="FORM.SENIOR_CITIZEN_NO"></td>

                                 <td>Medicare:
                                    <select ng-model="FORM.MEDICARE" name="MEDICARE" required="required">
                                      <option value="NON MEDICARE">NON MEDICARE</option>
                                      <option value="GOVERNMENT MEMBER">GOVERNMENT MEMBER</option>
                                      <option value="GOVERNMENT DEPENDENT">GOVERNMENT DEPENDENT</option>
                                      <option value="PRIVATE MEMBER">PRIVATE MEMBER</option>
                                      <option value="PRIVATE DEPENDENT">PRIVATE DEPENDENT</option>
                                      <option value="OWWA MEMBER">OWWA MEMBER</option>
                                      <option value="OWWA DEPENDENT">OWWA DEPENDENT</option>
                                      <option value="INDIGENT MEMBER">INDIGENT MEMBER</option>
                                      <option value="INDIGENT DEPENDENT">INDIGENT DEPENDENT</option>
                                      <option value="SELF-EMPLOYED MEMBER">SELF-EMPLOYED MEMBER</option>
                                      <option value="SELF-EMPLOYED DEPENDENT">SELF-EMPLOYED DEPENDENT</option>
                                      <option value="NON-PAYING MEMBER">NON-PAYING MEMBER</option>
                                      <option value="NON-PAYING DEPENDENT">NON-PAYING DEPENDENT</option>
                                      <option value="SPONSORED MEMBER">SPONSORED MEMBER</option>
                                      <option value="SPONSORED DEPENDENT">SPONSORED DEPENDENT</option>
                                      <option value="SENIOR CITIZEN MEMBER">SENIOR CITIZEN MEMBER</option>
                                      <option value="SENIOR CITIZEN DEPENT">SENIOR CITIZEN DEPENT</option>
                                      <option value="MIGRANT MEMBER">MIGRANT MEMBER</option>
                                      <option value="MIGRANT DEPENDENT">MIGRANT DEPENDENT</option>
                                      <option value="INFORMAL MEMBER">INFORMAL MEMBER</option>
                                      <option value="INFORMAL DEPENDENT">INFORMAL DEPENDENT</option>
                                      <option value="LIFETIME MEMBER">LIFETIME MEMBER</option>
                                      <option value="LIFETIME DEPENDENT">LIFETIME DEPENDENT</option>
                                    </select>

                             

                                </td>

                                
                              </tr>

                               <tr>

                                  <td>Plan:<input type="text" name="PLAN" ng-model="FORM.PLAN" ></td>

                                 <td>Blood Type:<input type="text" name="BLOOD_TYPE" ng-model="FORM.BLOOD_TYPE"></td>

                                  <td>RH:<input type="text" name="RH" ng-model="FORM.RH"></td>
                                 
                              </tr>

                                <tr>
                                
                                 <td>Allergies:<input type="text" name="ALLERGIES" ng-model="FORM.ALLERGIES"></td>

                                    <td>SC Date Issue:<input ng-model="FORM.SC_DATE_ISSUE"type="date" name="SC_DATE_ISSUE"></td>
                              </tr>


                         </table>

                      </div>


               
          </section>
            <section id="rauchbier" class="tab-panel">
             <table>
                            <tr>
                              <th>Patient's Father</th>
                            </tr>
                            <tr>
                              <td>Father name:<input type="text" name="FATHER_NAME" ng-model="FORM.FATHER_NAME"></td>

                              <td>Address:<input type="text" name="FATHER_ADDRESS" ng-model="FORM.FATHER_ADDRESS"></td>

                              <td>Telephone No:<input type="text" name="FATHER_TELEPHONE_NO" ng-model="FORM.FATHER_TELEPHONE_NO"></td>
                              

                            </tr>
                          

                              <tr>
                              <th>Mother's Father</th>
                            </tr>
                            <tr>
                              <td>Mother name:<input type="text" name="MOTHER_NAME" ng-model="FORM.MOTHER_NAME"></td>
                              <td>Address:<input type="text" name="MOTHER_ADDRESS" ng-model="FORM.MOTHER_ADDRESS"></td>
                              
                              <td>Telephone No:<input type="text" name="MOTHER_TELEPHONE_NO" ng-model="FORM.MOTHER_TELEPHONE_NO"></td>

                            </tr>
                           

                             <tr>
                              <th>Patient's Spouse</th>
                            </tr>
                            
                               <tr>
                              <td>Spouse name:<input type="text" name="SPOUSE_NAME" ng-model="FORM.SPOUSE_NAME"></td>
                              <td>Address:<input type="text" name="SPOUSE_ADDRESS" ng-model="FORM.SPOUSE_ADDRESS"></td>

                            </tr>
                            <tr>
                              <td>Telephone No:<input type="text" name="SPOUSE_TELEPHONE_NO" ng-model="FORM.SPOUSE_TELEPHONE_NO"></td>
                              <td>Occupation:<input type="text" name="SPOUSE_OCCUPATION" ng-model="FORM.SPOUSE_OCCUPATION"></td>
                              

                              
                            </tr>

                             <tr>
                              <th>In-case of Emergency</th>
                            </tr>
                            
                               <tr>
                              <td>Emergency name:<input type="text" name="EMERGENCY_NAME" ng-model="FORM.EMERGENCY_NAME"></td>
                              <td>Address:<input type="text" name="EMERGENCY_ADDRESS" ng-model="FORM.EMERGENCY_ADDRESS"></td>

                            </tr>
                            <tr>
                              <td>Relation:
                                <!-- <input type="text" name="EMERGENCY_RELATION" ng-model="FORM.EMERGENCY_RELATION"> -->

                              <select ng-model="FORM.EMERGENCY_RELATION" name="EMERGENCY_RELATION" required="required">
                                      <option value="NON MEDICARE">AUNT</option>
                                      <option value="GOVERNMENT MEMBER">BESTFRIEND</option>
                                      <option value="GOVERNMENT DEPENDENT">BOYFRIEND</option>
                                      <option value="PRIVATE MEMBER">BROTHER</option>
                                      <option value="PRIVATE DEPENDENT">SISTER</option>
                                      <option value="OWWA MEMBER">CO-EMPOLYEE</option>
                                      <option value="OWWA DEPENDENT">COUSIN</option>
                                      <option value="INDIGENT MEMBER">DAUGHTER</option>
                                      <option value="INDIGENT DEPENDENT">SON</option>
                                      <option value="SELF-EMPLOYED MEMBER">DAUGHTER-IN-LAW</option>
                                      <option value="SELF-EMPLOYED DEPENDENT">SON-IN-LAW</option>
                                      <option value="NON-PAYING MEMBER">FATHER-IN-LAW</option>
                                      <option value="NON-PAYING DEPENDENT">MOTHER-IN-LAW</option>
                                      <option value="SPONSORED MEMBER">GIRLFRIEND</option>
                                      <option value="SPONSORED DEPENDENT">GRANDMOTHER</option>
                                      <option value="SENIOR CITIZEN MEMBER">GRANDFATHER</option>
                                      <option value="SENIOR CITIZEN DEPENT">GUARDIAN</option>
                                      <option value="MIGRANT MEMBER">HUSBAND</option>
                                      <option value="MIGRANT DEPENDENT">WIFE</option>
                                    </select>



                              </td>
                              <td>Telephone No:<input type="text" name="EMERGENCY_TELEPHONE_NO" ng-model="FORM.EMERGENCY_TELEPHONE_NO">
                              </td>
                             
                            </tr>


                             <tr>
                              <th>Patient's Employer</th>
                            </tr>
                            
                               <tr>
                              <td>Employer Name:<input type="text" name="PE_EMPLOYER_NAME" ng-model="FORM.PE_EMPLOYER_NAME"></td>
                              <td>Address:<input type="text" name="PE_ADDRESS" ng-model="FORM.PE_ADDRESS"></td>
                              <td>Telephone No:<input type="text" name="PE_TELEPHONE_NO" ng-model="FORM.PE_TELEPHONE_NO"></td>

                            </tr>
                            

                          </table> 
            </section>
            <section id="dunkles" class="tab-panel">
             <table>
                            <tr>
                              <th>Name of Member and Identification</th>
                            </tr>
                            <tr>
                              <td>Phic No.:<input type="text" name="MI_PHIC_NO" ng-model="FORM.MI_PHIC_NO"></td>

                            </tr>

                            <tr>
                             <td>Lastname.:<input type="text" name="MI_LASTNAME" ng-model="FORM.MI_LASTNAME"></td>

                              <td>Firstname.:<input type="text" name="MI_FIRSTNAME" ng-model="FORM.MI_FIRSTNAME"></td>

                              <td>Middlename.:<input type="text" name="MI_MIDDLENAME" ng-model="FORM.MI_MIDDLENAME"></td>

                              <td>Suffix.:<input type="text" name="MI_SUFFIX" ng-model="FORM.MI_SUFFIX"></td>

                            </tr>

                            <tr>
                             <td>Sex.:<input type="text" name="MI_SEX" ng-model="FORM.MI_SEX"></td>

                              <td>DOB.:<input type="text" name="MI_DOB" ng-model="FORM.MI_DOB"></td>

                              <td>Member Relation.:<input type="text" name="MI_MEMBER_RELATION" ng-model="FORM.MI_MEMBER_RELATION"></td>
                             
                            </tr>

                            <tr>
                             <td>Membership Type:<input type="text" name="MI_MEMBERSHIP_TYPE" ng-model="FORM.MI_MEMBERSHIP_TYPE"></td>

                              <td>Email.:<input type="text" name="MI_EMAIL" ng-model="FORM.MI_EMAIL"></td>

                              <td>Contact No..:<input type="text" name="MI_CONTACT" ng-model="FORM.MI_CONTACT"></td>
                             
                            </tr>

                             
                      
                            <tr>
                              <th>Address of Member</th>
                            </tr>
                            <tr>
                              <td>No. Street:<input type="text" name="AM_NO_STREET" ng-model="FORM.AM_NO_STREET"></td>

                              <td>Municipality City:<input type="text" name="AM_MUNICIPALITY_CITY" ng-model="FORM.AM_MUNICIPALITY_CITY"></td>

                            </tr>

                             <tr>
                              <td>Barangay:<input type="text" name="AM_BARANGAY" ng-model="FORM.AM_BARANGAY"></td>

                              <td>Province:<input type="text" name="AM_PROVINCE" ng-model="FORM.AM_PROVINCE"></td>

                              <td>Zipcode:<input type="text" name="AM_ZIPCODE" ng-model="FORM.AM_ZIPCODE"></td>

                            </tr>
                             <tr>
                              <th>Patient's Employer</th>
                            </tr>
                            
                               <tr>
                              <td>Employer's Name:<input type="text" name="PHIC_PE_NAME" ng-model="FORM.PHIC_PE_NAME"></td>
                              <td>Address:<input type="text" name="PHIC_PE_ADDRESS" ng-model="FORM.PHIC_PE_ADDRESS"></td>
                              <td>Contact No:<input type="text" name="PHIC_PE_CONTACT_NO" ng-model="FORM.PHIC_PE_CONTACT_NO"></td>
                              <td>PEN (PHIC Employer Number):<input type="text" name="PHIC_PE_PIN" ng-model="FORM.PHIC_PE_PIN"></td>

                            </tr>
                            <tr>
                             

                            </tr>
                            <tr> </tr>


                          </table> 
            </section>
          </div>
                 
              <button class="btn btn-primary pull-right" type="submit" class="button" ><span>Update</span>  </button>
            
          </div>




        </form>


  </div>







                    
                  </div>
                </div>
              </div>
            </div>
      <footer class="footer">
        
      </footer>
    </div>
  </div>
  
  <!--   Core JS Files   -->
  <script src="<?php echo base_url('asset/js/core/jquery.min.js')?>"></script>
  <script src="<?php echo base_url('asset/js/core/popper.min.js')?>"></script>
  <script src="<?php echo base_url('asset/js/core/bootstrap-material-design.min.js')?>"></script>
  <script src="<?php echo base_url('asset/js/plugins/perfect-scrollbar.jquery.min.js')?>"></script>
  <!-- Plugin for the momentJs  -->
  <script src="<?php echo base_url('asset/js/plugins/moment.min.js')?>"></script>
  <!--  Plugin for Sweet Alert -->
  <script src="<?php echo base_url('asset/js/plugins/sweetalert2.js')?>"></script>
  <!-- Forms Validations Plugin -->
  <script src="<?php echo base_url('asset/js/plugins/jquery.validate.min.js')?>"></script>
  <!-- Plugin for the Wizard, full documentation here: https://github.com/VinceG/twitter-bootstrap-wizard -->
  <script src="<?php echo base_url('asset/js/plugins/jquery.bootstrap-wizard.js')?>"></script>
  <!--  Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
  <script src="<?php echo base_url('asset/js/plugins/bootstrap-selectpicker.js')?>"></script>
 
  <!--  DataTables.net Plugin, full documentation here: https://datatables.net/  -->
  <script src="<?php echo base_url('asset/js/plugins/jquery.dataTables.min.js')?>"></script>
  <!--  Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
  <script src="<?php echo base_url('asset/js/plugins/bootstrap-tagsinput.js')?>"></script>
  <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
  <script src="<?php echo base_url('asset/js/plugins/jasny-bootstrap.min.js')?>"></script>
  <!--  Full Calendar Plugin, full documentation here: https://github.com/fullcalendar/fullcalendar    -->
  <script src="<?php echo base_url('asset/js/plugins/fullcalendar.min.js')?>"></script>
  <!-- Vector Map plugin, full documentation here: http://jvectormap.com/documentation/ -->
  <script src="<?php echo base_url('asset/js/plugins/jquery-jvectormap.js')?>"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="<?php echo base_url('asset/js/plugins/nouislider.min.js')?>"></script>
  <!-- Include a polyfill for ES6 Promises (optional) for IE11, UC Browser and Android browser support SweetAlert -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
  <!-- Library for adding dinamically elements -->
  <script src="<?php echo base_url('asset/js/plugins/arrive.min.js')?>"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chartist JS -->
  <script src="<?php echo base_url('asset/js/plugins/chartist.min.js')?>"></script>
  <!--  Notifications Plugin    -->
  <script src="<?php echo base_url('asset/js/plugins/bootstrap-notify.js')?>"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="<?php echo base_url('asset/js/material-dashboard.js?v=2.1.2')?>" type="text/javascript"></script>
  
 
</body>
  </html>

    

      



       