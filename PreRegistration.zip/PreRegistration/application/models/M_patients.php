<?php
	defined('BASEPATH') OR exit ('NO direct script access allowed');

	class M_patients extends CI_Model
	{
		function __construct(){$this->load->database();}

 

		function submit_form_registration()
		{

			$_POST += json_decode(file_get_contents('php://input'), true);
			$this->db->insert('patient_information',array(
				'LASTNAME'=>$_POST['LASTNAME'],
				'FIRSTNAME'=>$_POST['FIRSTNAME'],
				'MIDDLENAME'=>$_POST['MIDDLENAME'],
				'SUFFIX'=>$_POST['SUFFIX'],
				'SEX'=>$_POST['SEX'],
				'CIVIL_STATUS'=>$_POST['CIVIL_STATUS'],
				'DATE_OF_BIRTH'=>$_POST['DATE_OF_BIRTH'],
				'NBCONDITION'=>$_POST['NBCONDITION'],
				'FILE_NO'=>$_POST['FILE_NO'],
				'DATEREG'=>$_POST['DATEREG'],
				'OCCUPATION'=>$_POST['OCCUPATION'],
				'RELIGION'=>$_POST['RELIGION'],
				'NATIONALITY'=>$_POST['NATIONALITY'],
				'TELNO'=>$_POST['TELNO'],
				'PLACE_BIRTH'=>$_POST['PLACE_BIRTH'],
				'NO_STREET'=>$_POST['NO_STREET'],
				'PROVINCE'=>$_POST['PROVINCE'],
				'CITY_MUNICIPALITY'=>$_POST['CITY_MUNICIPALITY'],
				'BARANGAY'=>$_POST['BARANGAY'],
				'ZIPCODE'=>$_POST['ZIPCODE'],
				'COMPANY'=>$_POST['COMPANY'],
				'ADDRESS'=>$_POST['ADDRESS'],
				'HEALTH_INSURANCE'=>$_POST['HEALTH_INSURANCE'],
				'HEALTH_INSURANCE_ADDRESS'=>$_POST['HEALTH_INSURANCE_ADDRESS'],
				'RH'=>$_POST['RH'],
				'CREDIT_LIMIT'=>$_POST['CREDIT_LIMIT'],
				'SENIOR_CITIZEN_NO'=>$_POST['SENIOR_CITIZEN_NO'],
				'MEDICARE'=>$_POST['MEDICARE'],
				'PLAN'=>$_POST['PLAN'],
				'BLOOD_TYPE'=>$_POST['BLOOD_TYPE'],
				'ALLERGIES'=>$_POST['ALLERGIES'],
				'SC_DATE_ISSUE'=>$_POST['SC_DATE_ISSUE'],
				'FATHER_NAME'=>$_POST['FATHER_NAME'],
				'FATHER_ADDRESS'=>$_POST['FATHER_ADDRESS'],
				'FATHER_TELEPHONE_NO'=>$_POST['FATHER_TELEPHONE_NO'],
				'MOTHER_NAME'=>$_POST['MOTHER_NAME'],
				'MOTHER_ADDRESS'=>$_POST['MOTHER_ADDRESS'],
				'MOTHER_TELEPHONE_NO'=>$_POST['MOTHER_TELEPHONE_NO'],
				'SPOUSE_NAME'=>$_POST['SPOUSE_NAME'],
				'SPOUSE_ADDRESS'=>$_POST['SPOUSE_ADDRESS'],
				'SPOUSE_TELEPHONE_NO'=>$_POST['SPOUSE_TELEPHONE_NO'],
				'SPOUSE_OCCUPATION'=>$_POST['SPOUSE_OCCUPATION'],
				'EMERGENCY_NAME'=>$_POST['EMERGENCY_NAME'],
				'EMERGENCY_ADDRESS'=>$_POST['EMERGENCY_ADDRESS'],
				'EMERGENCY_RELATION'=>$_POST['EMERGENCY_RELATION'],
				'EMERGENCY_TELEPHONE_NO'=>$_POST['EMERGENCY_TELEPHONE_NO'],
				'MI_PHIC_NO'=>$_POST['MI_PHIC_NO'],
				'MI_LASTNAME'=>$_POST['MI_LASTNAME'],
				'MI_FIRSTNAME'=>$_POST['MI_FIRSTNAME'],
				'MI_MIDDLENAME'=>$_POST['MI_MIDDLENAME'],
				'MI_SUFFIX'=>$_POST['MI_SUFFIX'],
				'MI_SEX'=>$_POST['MI_SEX'],
				'MI_DOB'=>$_POST['MI_DOB'],
				'MI_MEMBER_RELATION'=>$_POST['MI_MEMBER_RELATION'],
				'MI_MEMBERSHIP_TYPE'=>$_POST['MI_MEMBERSHIP_TYPE'],
				'MI_EMAIL'=>$_POST['MI_EMAIL'],
				'MI_CONTACT'=>$_POST['MI_CONTACT'],
				'AM_NO_STREET'=>$_POST['AM_NO_STREET'],
				'AM_MUNICIPALITY_CITY'=>$_POST['AM_MUNICIPALITY_CITY'],
				'AM_BARANGAY'=>$_POST['AM_BARANGAY'],
				'AM_PROVINCE'=>$_POST['AM_PROVINCE'],
				'AM_ZIPCODE'=>$_POST['AM_ZIPCODE'],
				'PHIC_PE_NAME'=>$_POST['PHIC_PE_NAME'],
				'PHIC_PE_ADDRESS'=>$_POST['PHIC_PE_ADDRESS'],
				'PHIC_PE_CONTACT_NO'=>$_POST['PHIC_PE_CONTACT_NO'],
				'PHIC_PE_PIN'=>$_POST['PHIC_PE_PIN'],

			));

			echo "string";
		}

			

		  function search_patient()
		    {
		        $hasil=$this->db->get('patient_information');
		        return $hasil->result();
		    }


		     function edit_patientdata()
		    {
		    	$_POST += json_decode(file_get_contents('php://input'), true);
				$id=$this->input->post('id');
				$sql = $this->db->query("SELECT * 
					FROM patient_information  
					where id=?",array($id))->row();
				return $sql;
			}

				//chito
			public function deleteData($id){
				$this->db->where('id',$id);
				$this->db->delete('patient_information');
			}
			//chito
			public function UpdatePaitentData($data,$id)
			{
			   $this->db->where('id',$id);
			   $this->db->update('patient_information',$data);

			}

 
			

	// 		 function update_patientdata()
	// 	    {
		    
	// 		$data = array(
	// 			'LASTNAME' => $this->input->post('up_posLASTNAMEition'),
	// 			'FIRSTNAME' => $this->input->post('FIRSTNAME'),
	// 			'MIDDLENAME' => $this->input->post('MIDDLENAME'),
	// 			'SUFFIX' => $this->input->post('SEX'),
	// 			'SEX' => $this->input->post('up_middle'),
	// 			'CIVIL_STATUS' => $this->input->post('CIVIL_STATUS'),
	// 			'DATE_OF_BIRTH' => $this->input->post('DATE_OF_BIRTH'),
	// 			'NBCONDITION' => $this->input->post('NBCONDITION'),
	// 			'FILE_NO' => $this->input->post('FILE_NO'),
	// 			'DATEREG' => $this->input->post('DATEREG'),
	// 			'OCCUPATION' => $this->input->post('OCCUPATION'),
	// 			'RELIGION' => $this->input->post('RELIGION'),
	// 			'NATIONALITY' => $this->input->post('NATIONALITY'),
	// 			'TELNO' => $this->input->post('TELNO'),
	// 			'PLACE_BIRTH' => $this->input->post('PLACE_BIRTH'),
	// 			'NO_STREET' => $this->input->post('NO_STREET'),
	// 			'PROVINCE' => $this->input->post('PROVINCE'),
	// 			'CITY_MUNICIPALITY' => $this->input->post('CITY_MUNICIPALITY'),
	// 			'BARANGAY' => $this->input->post('BARANGAY'),
	// 			'ZIPCODE' => $this->input->post('ZIPCODE'),
	// 			'COMPANY' => $this->input->post('COMPANY'),
	// 			'ADDRESS' => $this->input->post('ADDRESS'),
	// 			'HEALTH_INSURANCE' => $this->input->post('HEALTH_INSURANCE'),
	// 			'HEALTH_INSURANCE_ADDRESS' => $this->input->post('HEALTH_INSURANCE_ADDRESS'),
	// 			'RH' => $this->input->post('RH'),
	// 			'CREDIT_LIMIT' => $this->input->post('CREDIT_LIMIT'),
	// 			'SENIOR_CITIZEN_NO' => $this->input->post('SENIOR_CITIZEN_NO'),
	// 			'MEDICARE' => $this->input->post('MEDICARE'),
	// 			'PLAN' => $this->input->post('PLAN'),
	// 			'BLOOD_TYPE' => $this->input->post('BLOOD_TYPE'),
	// 			'ALLERGIES' => $this->input->post('ALLERGIES'),
	// 			'SC_DATE_ISSUE' => $this->input->post('SC_DATE_ISSUE')
 //    		);
 //    		$this->db->where('id', $id);
 //    		$this->db->update("patient_information", $data);
 //    		return $id;
 //    	}


			function delete_patientdata()
			{
				 $this->db->where("id");  
          		 $this->db->delete("patient_information");  
           //DELETE FROM users WHERE id = '$user_id'  

			}	

	// 		function delete_patientdata(){
	// 	$id = $this->input->get('id');
	// 	$this->db->where('id', $id);
	// 	$this->db->delete('patient_information');
	// 	if($this->db->affected_rows() > 0){
	// 		return true;
	// 	}else{
	// 		return false;
	// 	}
	// }	


	}


?>